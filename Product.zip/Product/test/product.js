var Product = artifacts.require("./Product.sol");

contract("Product", function(accounts) {
  var productvoteInstance;

  it("initializes with two features", function() {
    return Product.deployed().then(function(instance) {
      return instance.featuresCount();
    }).then(function(count) {
      assert.equal(count, 2);
    });
  });

  it("it initializes the features with the correct values", function() {
    return Product.deployed().then(function(instance) {
      productvoteInstance = instance;
      return productvoteInstance.features(1);
    }).then(function(feature) {
      assert.equal(feature[0], 1, "contains the correct id");
      assert.equal(feature[1], "Feature 1", "contains the correct name");
      assert.equal(feature[2], 0, "contains the correct votes count");
      return productvoteInstance.features(2);
    }).then(function(feature) {
      assert.equal(feature[0], 2, "contains the correct id");
      assert.equal(feature[1], "Feature 2", "contains the correct name");
      assert.equal(feature[2], 0, "contains the correct votes count");
    });
  });

  it("allows a voter to cast a vote", function() {
    return Product.deployed().then(function(instance) {
      electionInstance = instance;
      featureId = 1;
      return electionInstance.vote(featureId, { from: accounts[0] });
    }).then(function(receipt) {
      assert.equal(receipt.logs.length, 1, "an event was triggered");
      assert.equal(receipt.logs[0].event, "votedEvent", "the event type is correct");
      assert.equal(receipt.logs[0].args._featureId.toNumber(), featureId, "the feature id is correct");
      return electionInstance.voters(accounts[0]);
    }).then(function(voted) {
      assert(voted, "the voter was marked as voted");
      return electionInstance.features(featureId);
    }).then(function(feature) {
      var voteCount = feature[2];
      assert.equal(voteCount, 1, "increments the feature's vote count");
    })
  });

  it("throws an exception for invalid features", function() {
    return Product.deployed().then(function(instance) {
      electionInstance = instance;
      return electionInstance.vote(99, { from: accounts[1] })
    }).then(assert.fail).catch(function(error) {
      assert(error.message.indexOf('revert') >= 0, "error message must contain revert");
      return electionInstance.features(1);
    }).then(function(feature1) {
      var voteCount = feature1[2];
      assert.equal(voteCount, 1, "feature 1 did not receive any votes");
      return electionInstance.features(2);
    }).then(function(feature2) {
      var voteCount = feature2[2];
      assert.equal(voteCount, 0, "feature 2 did not receive any votes");
    });
  });

  it("throws an exception for double voting", function() {
    return Product.deployed().then(function(instance) {
      electionInstance = instance;
      featureId = 2;
      electionInstance.vote(featureId, { from: accounts[1] });
      return electionInstance.features(featureId);
    }).then(function(feature) {
      var voteCount = feature[2];
      assert.equal(voteCount, 1, "accepts first vote");
      // Try to vote again
      return electionInstance.vote(featureId, { from: accounts[1] });
    }).then(assert.fail).catch(function(error) {
      assert(error.message.indexOf('revert') >= 0, "error message must contain revert");
      return electionInstance.features(1);
    }).then(function(feature1) {
      var voteCount = feature1[2];
      assert.equal(voteCount, 1, "feature 1 did not receive any votes");
      return electionInstance.features(2);
    }).then(function(feature2) {
      var voteCount = feature2[2];
      assert.equal(voteCount, 1, "feature 2 did not receive any votes");
    });
  });

});